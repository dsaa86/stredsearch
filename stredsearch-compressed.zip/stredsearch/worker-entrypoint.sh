#!/bin/sh
python /usr/src/manage.py rqworker default